#pragma once

#include <mutex>
#include <vector>
#include <initializer_list>
#include <string>

class Philosopher
{
private:
  int number;
  std::timed_mutex &leftFork;
  std::timed_mutex &rightFork;
  int forkTimeout;
  void getForks();
  void releaseForks();

public:
  Philosopher(int _number, std::timed_mutex &_leftFork, std::timed_mutex &_rightFork);
  ~Philosopher();
  void eat();
};