#include "philosopher.h"
#include <thread>
#include <chrono>
#include <iostream>

using namespace std;

Philosopher::Philosopher(int _number, std::timed_mutex &_leftFork, std::timed_mutex &_rightFork) : leftFork(_leftFork), rightFork(_rightFork)
{
    number = _number;
}

Philosopher::~Philosopher()
{
}

void Philosopher::getForks()
{
    std::cout << "Philosopher " << to_string(number) << " attempts to get left fork" << endl;
    leftFork.lock();
    std::this_thread::sleep_for(std::chrono::seconds(5));

    std::cout << "Philosopher " << to_string(number) << " got left fork. Now he wants the right one..." << endl;
    auto start = std::chrono::steady_clock::now();
    if (!rightFork.try_lock_until(start + std::chrono::seconds(forkTimeout)))
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        leftFork.unlock();
        std::cout << "Philosopher " << to_string(number) << " released left fork due to timeout getting the right one!" << endl;
        std::this_thread::sleep_for(std::chrono::seconds(3));
        getForks();
    }
}

void Philosopher::releaseForks()
{
    leftFork.unlock();
    std::cout << "Philosopher " << to_string(number) << " released left fork" << endl;

    rightFork.unlock();
    std::cout << "Philosopher " << to_string(number) << " released right fork" << endl;
}

void Philosopher::eat()
{
    std::cout << string{"Philosopher "} << to_string(number) << string{" is thinking..."} << endl;
    std::this_thread::sleep_for(std::chrono::seconds(1));

    getForks();

    std::this_thread::sleep_for(std::chrono::seconds(2));
    std::cout << "Philosopher " << to_string(number) << " finished eating" << endl;

    releaseForks();
}
